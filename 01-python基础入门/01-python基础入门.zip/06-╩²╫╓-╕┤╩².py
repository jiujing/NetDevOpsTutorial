if __name__ == '__main__':
    # 复数。了解即可，实际中很少遇到
    a = 1-3j
    b = 1+3j
    print(a+b)
