from keyword import kwlist
# 关键字，也称保留字，禁止用于命名变量、方法、对象等。
# 每个版本的python关键字不尽相同，可以使用以下方法查看对应python版本的关键字
# 但是常用的基本就是那几个
if __name__ == '__main__':
    print(kwlist)
