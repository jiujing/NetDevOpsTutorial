if __name__ == '__main__':
    """
    布尔值True False
    * 其实是int的一个子类
    """
    flag1 = True
    flag2 = False
    # 布尔运算有 and or not三种

    # and是且运算
    # or是或预算
    # not 是取反
    print('f1 and f2:', flag1 and flag2)
    print('f1 and f2:', flag1 or flag2)
    print('not f1:', not flag1)
    print('not f2:', not flag2)
