if __name__ == '__main__':

    a = [1,2,3,4,5]
    for i in a:
        # 等于2的时候,continue以下的逻辑块不会执行，所以不会打印2
        if i == 2:
            break
        print(i)